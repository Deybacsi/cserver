#include <stdio.h>
#include <string.h>
#include "http.h"

int main() {
    startServer();
}