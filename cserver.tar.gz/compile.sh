make clean
make
./server