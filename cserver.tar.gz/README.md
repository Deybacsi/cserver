# Simple C server with client

For detailed documentation, please check [https://deybacsi.github.io/cserver](https://deybacsi.github.io/cserver)

